# pi-cc-monitor

> 把 Claude Code 的 `Monitor` 搬到 Pi：后台命令或 WebSocket 的每一行输出都是一个事件，事件会唤醒 agent。

## 快速开始

```bash
# 本地开发：把仓库软链接到 Pi 扩展目录
ln -sfn "$PWD" ~/.pi/agent/extensions/pi-cc-monitor

# 发布后
pi install npm:pi-cc-monitor
```

安装后执行 `/reload`。

## 功能

| 功能 | 说明 | 入口 |
| --- | --- | --- |
| 后台监视 | 命令 stdout 每行 = 一个事件；进程退出结束 | `Monitor` |
| WebSocket | 每个 text frame = 一个事件，binary 记为占位行 | `Monitor` |
| 事件唤醒 | 事件到达即开一轮 agent turn | 自动 |
| 超时/常驻 | `timeout_ms` 默认 5 分钟；`persistent` 到会话结束 | `Monitor` |
| 批量 | 200ms 内的行合并成一条通知 | 自动 |
| 洪水保护 | 输出过量自动停止 | 自动 |
| 停止/列表 | 按 id 停止、列出状态与退出码 | `monitor_stop` / `monitor_list` |

## 工具

| 工具 | 说明 |
| --- | --- |
| `Monitor` | 起一个后台监视 |
| `monitor_stop` | 按 id 停止 |
| `monitor_list` | 列出状态、事件数、退出码；退出后时长冻结 |

### Monitor 参数

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `command` | string? | 脚本；stdout 每行一个事件，退出结束 |
| `ws` | object? | `{ url, protocols? }`；text frame 一个事件 |
| `description` | string | 出现在每条通知里 |
| `timeout_ms` | number? | 1000–3600000，默认 300000 |
| `persistent` | boolean? | 会话级常驻，不超时 |
| `loopPrompt` | string? | 属于哪条 `/loop` chain；事件会顶掉它的兜底心跳 |

`command` 和 `ws` 二选一。

## 用法

**等一个事件**

```json
{
  "command": "until curl -sf localhost:3000/health; do sleep 1; done",
  "description": "server is up"
}
```

**盯日志**

```json
{
  "command": "tail -f deploy.log | grep --line-buffered ERROR",
  "description": "deploy errors"
}
```

**配合 loop**

```text
/loop check whether the deploy finished
```

模型会起一个带 `loopPrompt` 的 Monitor；事件到达时立即唤醒 loop，`schedule_wakeup` 的延迟只作为兜底心跳。

## 规则

- 只有 stdout 是事件流；stderr 写进文件，不触发唤醒
- 管道要逐行 flush：`grep --line-buffered`；`head` 不行
- 只匹配成功标记的脚本在 crash/hang 时会静默；把 `ERROR|FAILED|Killed` 也覆盖进去
- `tail -f` / `while true` 不会自己退出；不需要时用 `monitor_stop` 或 `timeout_ms`
- 每行都是一条消息；测试时别一次打印几十行

## 设置

两个 pi-cc 扩展共享 `~/.pi/agent/pi-cc.json`：

```jsonc
{
  "compactMessages": true,          // 两行 marker / 旧的带底色卡片
  "compactToolRows": true,          // 一行工具结果 / Pi 默认工具行
  "managePiCcExtensions": true      // 自动维护 pi-cc-extensions 的 excludeRenderers
}
```

用 `/loop settings` 切换：

```text
/loop settings messages on|off
/loop settings tools on|off
```

> 如果装了 `pi-cc-extensions`，`tools on` 会把 `Monitor` / `monitor_stop` / `monitor_list`
> 加入它的 `excludeRenderers`；切换后需要 `/reload`。
> 设 `managePiCcExtensions: false` 关闭自动同步。

## 兼容性

- Node.js `>=22.19.0`
- Pi `1.3.0`（开发环境）
- `pi-cc-loop` 可选；两者通过 `pi.events` 通信

## 本地开发

```bash
node --test tests/*.test.mjs
npx --yes typescript@5.9.3 tsc --noEmit -p tsconfig.json
```

## 说明

- 行为对齐 Claude Code v2.1.306 的 `Monitor`，用 Pi 扩展 API 实现。
- `monitor_stop` / `monitor_list` 对应 CC 的 `TaskStop` / `TaskList`。
- 事件来源用消息前缀 `[monitor · ...]` 标记，而不是 CC 的 `<task-notification>` 元数据。
- 和 `pi-cc-loop` 一起用时，`/loop stop` 会停掉该 chain 绑定的 Monitor。

## 许可证

MIT
